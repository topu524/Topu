package com.example.topu

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
